## Tentang saya
Halo, Saya **A.M Hirin** seorang ***Penulis Buku IT***, ***International Freelance Programmer***, dan ***Senior Developer*** di Perusahaan Konsultan IT. Saya penggila kode dan sudah berkutat selama 15 tahun di dunia pemrograman. Anda membutuhkan bantuan terkait skill dan keahlian saya? Kontak saya melalui email : **nump.info@gmail.com**

# eduprog_flutter_login_php

Contoh aplikasi flutter untuk login dengan backend PHP dan MySQL

## Getting Started

Backend ada di folder *Backend*
- service.php : file php untuk service login
- eduprog.sql : file database MySQL
